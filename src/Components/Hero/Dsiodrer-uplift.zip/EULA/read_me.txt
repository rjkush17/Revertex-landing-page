
Hi!
Thank you for downloading this font.
My fonts are free for personal use. If you want 
to use one of my fonts for your commercial project, 
you can buy the commercial license by sending me 
10�/$15 through Paypal to address: 
junkohanhero@gmail.com
After the payment, send me e-mail.
You can also use the Donate button on Dafont, right 
under the Download button.
Regular donations are also welcome.

_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

www.dafont.com/junkohanhero.d1293
www.facebook.com/junkohanhero
www.facebook.com/JUNKOHANHEROFONTS
www.junkohanhero.com